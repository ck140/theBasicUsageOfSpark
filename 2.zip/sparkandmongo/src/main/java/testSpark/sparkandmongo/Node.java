package testSpark.sparkandmongo;

import java.io.Serializable;

public final class Node implements Serializable {
	private String ip;
	private long id;
	public String getIp(){
		return ip;
	}
	
	public void setIp(String ip){
		this.ip = ip;
	}

	public long getId(){
		return id;
	}
	
	public void setId(String ip){
		long[] sip = new long[4];  
        //先找到IP地址字符串中.的位置  
        int position1 = ip.indexOf(".");  
        int position2 = ip.indexOf(".", position1 + 1);  
        int position3 = ip.indexOf(".", position2 + 1);  
        //将每个.之间的字符串转换成整型  
        sip[0] = Long.parseLong(ip.substring(0, position1));  
        sip[1] = Long.parseLong(ip.substring(position1+1, position2));  
        sip[2] = Long.parseLong(ip.substring(position2+1, position3));  
        sip[3] = Long.parseLong(ip.substring(position3+1));  
        id = (sip[0] << 24) + (sip[1] << 16) + (sip[2] << 8) + sip[3];    
	}
}
