package testSpark.sparkandmongo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.bson.Document;
import org.graphframes.GraphFrame;

import com.mongodb.spark.MongoSpark;
import com.mongodb.spark.config.ReadConfig;
import com.mongodb.spark.config.WriteConfig;
import com.mongodb.spark.rdd.api.java.JavaMongoRDD;

import scala.Tuple2;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 /* Create the SparkSession.
         * If config arguments are passed from the command line using --conf,
         * parse args for the values to set.
         */
        SparkSession spark = SparkSession.builder()
          .master("local")
          .appName("MongoSparkConnectorIntro")
          .config("spark.mongodb.input.uri", "mongodb://127.0.0.1/project.package")
          .config("spark.mongodb.output.uri", "mongodb://127.0.0.1/project")
          .getOrCreate();

        
        // Create a JavaSparkContext using the SparkSession's SparkContext object
        JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

        // More application logic would go here...
        // Load data and infer schema, disregard toDF() name as it returns Dataset. 
        // Using Dataframe load data 
        
        // SQLContext sqlContext = SQLContext.getOrCreate(jsc.sc());
        Dataset<Row> df = MongoSpark.load(jsc).toDF();
       
        // Create the temp view and execute the query
        df.createOrReplaceTempView("package");
        //df.printSchema();
        //df.show();
        //Dataset<Row> src_table = sqlContext.sql("select ip_src as ip from package");
        //创建结点表
        Dataset<Row> src_table = spark.sql("select ip_src as ip from package");
    	Dataset<Row> dst_table = spark.sql("select ip_dst as ip from package");    	
    	Dataset<Row> node_table = src_table.union(dst_table).distinct();
    	//ntable.show();
        //将Dataset转换为RDD,用于构建相应的类
    	JavaRDD<Row> nrdd = node_table.javaRDD();
    	JavaRDD<Node> noderdd = nrdd.map(new Function<Row,Node>(){
    		public Node call(Row row) throws Exception{
    			Node n = new Node();
    			n.setIp(row.getString(0));
    			n.setId(row.getString(0));
    			return n;
    		}
    	});
        //将RDD转换为Dataset
    	Dataset<Row> nodtable = spark.createDataFrame(noderdd, Node.class);
    	// Write the data to the "node" collection
        MongoSpark.write(nodtable).option("collection", "node").mode("overwrite").save(); 
        
        
        // Load the data from the "node" collection
        //Dataset<Row> n_table = MongoSpark.load(spark, ReadConfig.create(spark).withOption("collection", "node"),Node.class).toDF();
        //n_table.show();

        //边表
        Dataset<Row> e_table = spark.sql("select ip_src, ip_dst from package");
        Dataset<Row> edge_table = e_table.distinct();
        
        JavaRDD<Row> erdd = edge_table.javaRDD();
        JavaRDD<Edges> edgerdd = erdd.map(new Function<Row,Edges>(){
        	public Edges call(Row row) throws Exception{
        		Edges e = new Edges();
        		e.setIp_src(row.getString(0));
        		e.setIp_dst(row.getString(1));
        		e.setsrcId(row.getString(0));
        		e.setdstId(row.getString(1));
        		e.setrelationship(row.getString(0), row.getString(1));
        		return e;
        	}
        });
        Dataset<Row> edgtable = spark.createDataFrame(edgerdd, Edges.class);
        edgtable.show();
        MongoSpark.write(edgtable).option("collection", "edge").mode("overwrite").save();
        //Dataset<Row> ed_table = MongoSpark.load(spark, ReadConfig.create(spark).withOption("collection", "edge"),Edge.class).toDF();
        //ed_table.show();
/*        edgtable.createOrReplaceTempView("edges");
        Dataset<Row> etable = spark.sql("select src, dst, relationship from edges");
        GraphFrame g = new GraphFrame(nodtable,etable);
        Dataset<Row> com = g.labelPropagation().maxIter(2).run();
        com.show();*/
        jsc.close();

      }
}

