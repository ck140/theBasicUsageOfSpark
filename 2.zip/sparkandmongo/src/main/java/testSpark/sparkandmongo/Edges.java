package testSpark.sparkandmongo;

import java.io.Serializable;

public final class Edges implements Serializable{
	private String ip_src;
	private String ip_dst;
	private Long src;
	private Long dst;
	private String relationship;
	
	public String getIp_src(){
		return ip_src;
	}
	
	public void setIp_src(String ip_src){
		this.ip_src = ip_src;
	}
	
	public String getIp_dst(){
		return ip_dst;
	}
	
	public void setIp_dst(String ip_dst){
		this.ip_dst = ip_dst;
	}
	
	public Long getsrc(){
		return src;
	}
	
	public void setsrcId(String ip_src){
		long[] srip = new long[4];  
        //先找到IP地址字符串中.的位置  
        int position1 = ip_src.indexOf(".");  
        int position2 = ip_src.indexOf(".", position1 + 1);  
        int position3 = ip_src.indexOf(".", position2 + 1);  
        //将每个.之间的字符串转换成整型  
        srip[0] = Long.parseLong(ip_src.substring(0, position1));  
        srip[1] = Long.parseLong(ip_src.substring(position1+1, position2));  
        srip[2] = Long.parseLong(ip_src.substring(position2+1, position3));  
        srip[3] = Long.parseLong(ip_src.substring(position3+1));  
        src = (srip[0] << 24) + (srip[1] << 16) + (srip[2] << 8) + srip[3];
	}
	
	public Long getdst(){
		return dst;
	}
	
	public void setdstId(String ip_dst){
		long[] dip = new long[4];  
        //先找到IP地址字符串中.的位置  
        int position1 = ip_dst.indexOf(".");  
        int position2 = ip_dst.indexOf(".", position1 + 1);  
        int position3 = ip_dst.indexOf(".", position2 + 1);  
        //将每个.之间的字符串转换成整型  
        dip[0] = Long.parseLong(ip_dst.substring(0, position1));  
        dip[1] = Long.parseLong(ip_dst.substring(position1+1, position2));  
        dip[2] = Long.parseLong(ip_dst.substring(position2+1, position3));  
        dip[3] = Long.parseLong(ip_dst.substring(position3+1));  
        dst = (dip[0] << 24) + (dip[1] << 16) + (dip[2] << 8) + dip[3];
	}
	public String getrelationship(){
		return relationship;
	}
	
	public void setrelationship(String ip_src,String ip_dst){
		this.relationship = ip_src+"--->"+ip_dst;
	}

}
